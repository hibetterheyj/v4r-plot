% this script generates the performance of your tracker and the baseline
% tracker on sequences with given attribute

clc
clear
close all

addpath('rstEval')

seqs = configSeqs;
result_path = 'F:\6_Approaching_Science\DataBase\UAV123Code\results\results_OPE';
ground_truth_path = 'F:\6_Approaching_Science\DataBase\UAV123Code\anno\UAV123_10FPS';
save_path = 'figs\analyse';
saveFormat = 'pdf'; % png 
att_path = [ground_truth_path,'\att'];
att_names={'SV'	'ARC'	'LR'	'FM'	'FOC'	'POC'	'OV'	'BC'	'IV'	'VC'	'CM'	'SOB'};
needed = {'CM' 'FM' 'VC'};  


FontName = 'Times'; % 'Times', 'Arial', 'Consolas'
TitleSize = 18;
TextSize = 12;
FigPos = [450 250 700 400]; % from the lower left point of your screen [xpos, ypos, xlength, ylength]
LineColor_ours = [0.8500 0.3250 0.0980]; % RGB as percentage
LineColor_base = [0.3010 0.7450 0.9330]; % RGB as percentage
LineWidth = 1;

tracker_name = 'ReCF';
baseline_name = 'SRDCF';


for i =1:size(seqs,2)
    
    % contain at least one in camera motion, fast motion or viewpoint change
    seq_att = dlmread([att_path '\' seqs{i}.name '.txt']);
    seq_att_name = att_names(seq_att~=0);
    hasAtt = false;
    for attCount = 1: numel(needed)
        if find(strcmp(seq_att_name, needed{attCount}))
            hasAtt = true;
            break
        end
    end
    
    if hasAtt
        
        video_name = seqs{i}.name;
        pred_name = [save_path '\' tracker_name '_' video_name];
        ground_truth = dlmread([ground_truth_path '\' video_name '.txt']);
        
        reso = load([result_path '\' tracker_name '\' video_name  '_' tracker_name  '.mat']);
        ours_res = reso.results{1};
        
        resb = load([result_path '\' baseline_name '\' video_name  '_' baseline_name  '.mat']);
        baseline_res = resb.results{1};
        
        [base_aveCoverage, base_aveErrCenter, base_errCoverage, base_errCenter] = calcSeqErrRobust(baseline_res, ground_truth);
        [ours_aveCoverage, ours_aveErrCenter, ours_errCoverage, ours_errCenter] = calcSeqErrRobust(ours_res, ground_truth);
        seq_len =  seqs{i}.endFrame - seqs{i}.startFrame  + 1;
        surpass = sum(ours_errCoverage - base_errCoverage)/seq_len;
        
        % set a threshold
        if surpass>0.1
            
            fram_num = 1:seq_len;
            
            % plot overlap success rate 
            overlap_fig = figure;
            plot(fram_num, ours_errCoverage,'color',LineColor_ours, 'LineWidth', LineWidth)
            hold on
            plot(fram_num, base_errCoverage,'color',LineColor_base, 'LineWidth', LineWidth)
            
            set(gca,'YLim',[0, 1.2]);
            set(gca, 'fontsize',TextSize,'fontname',FontName);
            set(gcf,'Position', FigPos)
            
            yticks([0:0.2:1])
            xlabel('Frame','fontweight','bold', 'FontSize', TitleSize, 'FontName', FontName)
            ylabel('Overlap', 'fontweight','bold', 'FontSize', TitleSize, 'FontName', FontName)
            legend(tracker_name, baseline_name,'location', 'northwest')
            tightfig
            saveas(overlap_fig, [pred_name '_Succ.' saveFormat])
            
            % plot center location error 
            centerErr_fig = figure;
            plot(fram_num, ours_errCenter,'color',LineColor_ours, 'LineWidth', LineWidth)
            hold on
            plot(fram_num, base_errCenter,'color',LineColor_base, 'LineWidth', LineWidth)
            
            set(gca, 'fontsize',TextSize,'fontname',FontName);
            set(gcf,'Position', FigPos)
            
            xlabel('Frame', 'fontweight','bold','FontSize', TitleSize, 'FontName', FontName)
            ylabel('Center Location Error', 'fontweight','bold','FontSize', TitleSize, 'FontName', FontName)
            legend(tracker_name, baseline_name,'location', 'northwest')
            tightfig
            saveas(centerErr_fig, [pred_name '_CLE.' saveFormat])
            
            close all
        end
    end
end

