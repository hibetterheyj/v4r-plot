close all

T = readtable('./res_record_lr=0.03.xlsx');
% T = readtable('./res_record_lr=0.032.xlsx');
% T = readtable('./res_record_lr=0.034.xlsx');
% T = readtable('./res_record_lr=0.036.xlsx');

plot_metric = {'UAVDT_Prec_', 'UAVDT_Succ_'}; % ��Ϊexcel�����.�����_
plot_title = {'Precision (at CLE �� 20 pixels) @ UAVDT', 'Success Rate (at AUC score) @ UAVDT'};
data_format = '%0.4f';
color_scaling = 'scaledcolumns'; % scaledcolumns:��ɫ���й�һ��; scaledrows:��ɫ���й�һ��; scaled:Ĭ�ϲ���

for idx_pm = 1 : numel(plot_metric)
    figure('NumberTitle', 'off', 'Name', plot_title{idx_pm});
    h = heatmap(T,'gamma', 'fintl', 'ColorVariable',plot_metric{idx_pm}, 'CellLabelFormat', data_format);
    h.ColorScaling = color_scaling;
    h.Title = plot_title{idx_pm};
    
%     h.YDisplayData = num2cell([12:-1:1]);
    colormap(cool);
end